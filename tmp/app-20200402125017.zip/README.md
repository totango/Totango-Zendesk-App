Zendesk App for Totango
===============

This is the [Totango App](http://www.zendesk.com/apps/totango) for New Zendesk. The app displays user and account information right next to support tickets. It is available to all Zendesk accounts via the [app listing](https://www.zendesk.com/apps/totango-insights/). Please submit bug reports to [Totango](http://support.totango.com/).
<br/>
Sceenshot of Totango Insights for Zendesk:<br/>
![Totango Insights for Zendesk](https://dl.dropboxusercontent.com/u/8381323/Totango%20Zendesk%20App%20RC1.png "Totango Insights for Zendesk")
